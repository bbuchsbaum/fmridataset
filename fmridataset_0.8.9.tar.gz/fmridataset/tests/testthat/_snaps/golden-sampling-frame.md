# sampling_frame print output matches snapshot

    Code
      print(sframe)
    Output
      Sampling Frame
      ==============
      
      Structure:
        3 blocks
        Total scans: 350
      
      Timing:
        TR: 2 s
        Precision: 0.1 s
      
      Duration:
        Total time: 700.0 s

