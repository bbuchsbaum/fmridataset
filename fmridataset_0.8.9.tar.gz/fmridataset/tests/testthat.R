library(testthat)
library(fmridataset)

test_check("fmridataset")
